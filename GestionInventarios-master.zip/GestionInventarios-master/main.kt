import view.InventoryView

fun main() {
    // Se crea una instancia de InventoryView, la clase que maneja la interfaz de usuario
    val inventoryView = InventoryView()

    // Se llama al metodo showMenu para iniciar la interacción con el usuario
    inventoryView.showMenu()
}
